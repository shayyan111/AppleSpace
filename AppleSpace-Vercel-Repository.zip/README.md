# AppleSpace website

A two-page static website: Home (coming soon) and About Us. No npm install or build step is needed.

## Repository files

- `public/index.html` — Home page
- `public/about/index.html` — About Us page
- `public/styles.css` — shared styles
- `public/phones-hero.webp` — Home image
- `public/applespace-logo.png` — transparent logo and favicon
- `vercel.json` — Vercel static site configuration

## Deploy with GitHub and Vercel

1. Create a new GitHub repository and upload **the contents** of this folder, keeping `public` and `vercel.json` at the repository root. Do not upload only the ZIP file.
2. In Vercel, choose **Add New → Project**, import that GitHub repository, and deploy.
3. The repository selects **Other** as the framework and `public` as the output directory. There is no build command.
4. Check `/` and `/about/` on the assigned Vercel URL.
5. To use your own domain, add it in **Vercel → Project → Settings → Domains**, then apply the DNS records Vercel shows in your domain registrar.

To update the site later, edit the files in `public` and push the changes to GitHub.
